import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec


class LoginPage:

    def __init__(self, driver):  # This is the constructor method (also known as __init__) of the LoginPage class
        self.login_test = driver

    """Locators of the elements"""
    username_locator_string = "username"
    # ---------------------------------------------
    password_locator = "password"
    # ---------------------------------------------
    login_btn_locator = "//form/div[3]/button"
    # ---------------------------------------------
    forgot_Password_link_locator = "//div[@class='orangehrm-login-forgot']//p[@class='oxd-text oxd-text--p " \
                                   "orangehrm-login-forgot-header']"

    # ---------------------------------------------
    forgot_password_page_title_locator = "//h6[@class='oxd-text oxd-text--h6 orangehrm-forgot-password-title']"
    # ---------------------------------------------
    username_textbox_locator = "//div[@class='oxd-input-group oxd-input-field-bottom-space']//div//following-sibling" \
                               "::div//input"
    # ---------------------------------------------
    reset_btn_locator = "//button[@type='submit']"
    # ---------------------------------------------
    reset_successful_page_title_locator = "//h6[text()= 'Reset Password link sent successfully']"
    # ---------------------------------------------
    cancel_btn_locator = "//button[@type='button']"
    # ---------------------------------------------
    login_page_title_locator = "//h5[@class='oxd-text oxd-text--h5 orangehrm-login-title']"
    # ---------------------------------------------
    required_username_alert_locator = "//span[@class='oxd-text oxd-text--span oxd-input-field-error-message " \
                                      "oxd-input-group__message']"

    def input_username(self, username):
        """this method get input for username"""
        self.login_test.find_element(By.NAME, self.username_locator_string).send_keys(username)

    def input_password(self, password):
        """this method get input for password"""
        self.login_test.find_element(By.NAME, self.password_locator).send_keys(password)

    def click_login_btn(self):
        """this method perform click action on login button"""
        self.login_test.find_element(By.XPATH, self.login_btn_locator).click()

    def click_forgot_password_link(self):
        """this method perform click action on forgot password link"""
        self.login_test.find_element(By.XPATH, self.forgot_Password_link_locator).click()
        time.sleep(2)

    def forgot_password_page(self):
        """this method validate the header of the forgot password page by getting text"""
        reset = WebDriverWait(self.login_test, 20). \
            until(ec.presence_of_element_located((By.XPATH, self.forgot_password_page_title_locator)))
        print(reset.text)
        assert reset

    def input_username_textbox(self, username):
        """this method get input for username"""
        self.login_test.find_element(By.XPATH, self.username_textbox_locator).send_keys(username)
        time.sleep(2)

    def click_reset_password_button(self):
        """this method perform click action on reset password button"""
        self.login_test.find_element(By.XPATH, self.reset_btn_locator).click()
        time.sleep(2)

    def forgot_password_reset_successful_page(self):
        """this method validate the forgot password reset successful page header"""
        reset = WebDriverWait(self.login_test, 20). \
            until(ec.presence_of_element_located((By.XPATH, self.reset_successful_page_title_locator)))
        print(reset.text)
        assert reset
        time.sleep(2)

    def click_cancel_button(self):
        """ this method perform click action on cancel button"""
        self.login_test.find_element(By.XPATH, self.cancel_btn_locator).click()
        time.sleep(2)

    def back_to_login_page(self):
        """ this method validate the login page header after navigate back from cancelling reset password """
        login_back = WebDriverWait(self.login_test, 20). \
            until(ec.presence_of_element_located((By.XPATH, self.login_page_title_locator)))
        print(login_back.text)
        assert login_back

    def required_username_alert(self):
        """this method validate whether alert comes after clicking on reset password button without username"""
        required = self.login_test.find_element(By.XPATH, self.required_username_alert_locator)
        print(required.text)
        assert required
        time.sleep(2)
