import string
import random


def take_screenshot(boss):
    number = 1
    result = ''.join(random.choices(string.ascii_uppercase + string.digits, k=number))
    boss.get_screenshot_as_file(f"C:\\Users\\Anand\\PycharmProjects\\Guvi_Project_2\\screenshot_save\\orange{result}.png")

