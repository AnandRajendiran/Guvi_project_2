import time

from selenium.webdriver.common.by import By


class AdminPage:

    def __init__(self, driver):  # This is the constructor method (also known as __init__) of the AdminPage class
        self.admin = driver

    """Locators of the elements"""

    admin_page_locator = "(//li[@class='oxd-main-menu-item-wrapper'])[1]//a"

    User_management_text_locator = "(//span[@class='oxd-topbar-body-nav-tab-item'])[1]"

    Job_text_locator = "(//span[@class='oxd-topbar-body-nav-tab-item'])[2]"

    Organization_text_locator = "(//span[@class='oxd-topbar-body-nav-tab-item'])[3]"

    Qualification_text_Locator = "(//span[@class='oxd-topbar-body-nav-tab-item'])[4]"

    Nationalities_text_locator = "//a[text() = 'Nationalities']"

    Corporate_Branding_text_locator = "//a[text() = 'Corporate Branding']"

    Configuration_text_locator = "(//span[@class='oxd-topbar-body-nav-tab-item'])[5]"

    def clicking_on_admin_page(self):
        """this method perform click action on admin page"""
        self.admin.find_element(By.XPATH, self.admin_page_locator).click()
        time.sleep(2)

    def validate_user_management_option_displays(self):
        """this method validate the header text of the user management section"""
        user_management_text = self.admin.find_element(By.XPATH, self.User_management_text_locator)
        print(f'a) {user_management_text.text}')
        time.sleep(2)

    def validate_job_option_displays(self):
        """this method validate the header text of the job section"""
        job_text = self.admin.find_element(By.XPATH, self.Job_text_locator)
        print(f'b) {job_text.text}')
        time.sleep(2)

    def validate_organization_option_displays(self):
        """this method validate the header text of the organization section"""
        organization_text = self.admin.find_element(By.XPATH, self.Organization_text_locator)
        print(f'c) {organization_text.text}')
        time.sleep(2)

    def validate_qualification_option_displays(self):
        """this method validate the header text of the qualification section"""
        qualification_text = self.admin.find_element(By.XPATH, self.Qualification_text_Locator)
        print(f'd) {qualification_text.text}')
        time.sleep(2)

    def validate_nationality_option_displays(self):
        """this method validate the header text of the nationality section"""
        nationality_text = self.admin.find_element(By.XPATH, self.Nationalities_text_locator)
        print(f'e) {nationality_text.text}')
        time.sleep(2)

    def validate_corporate_branding_option_displays(self):
        """this method validate the header text of the corporate branding section"""
        corporate_branding_text = self.admin.find_element(By.XPATH, self.Corporate_Branding_text_locator)
        print(f'f) {corporate_branding_text.text}')
        time.sleep(2)

    def validate_configure_option_displays(self):
        """this method validate the header text of the configuration section"""
        configuration_text = self.admin.find_element(By.XPATH, self.Configuration_text_locator)
        print(f'g) {configuration_text.text}')
        print("validated the options of the admin page")
        time.sleep(2)
