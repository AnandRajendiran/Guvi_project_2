import time

from selenium.webdriver.common.by import By


class AdminMenu:

    def __init__(self, driver):  # This is the constructor method (also known as __init__) of the AdminMenu class
        self.menu = driver

    """Locators of the elements"""

    admin_page_locator = "(//li[@class='oxd-main-menu-item-wrapper'])[1]//a"

    PIM_locator = "//span[text()= 'PIM']"

    Leave_locator = "//span[text()= 'Leave']"

    Time_locator = "//span[text()= 'Time']"

    Recruitment_locator = "//span[text()= 'Recruitment']"

    My_info_locator = "//span[text()= 'My Info']"

    Performance_locator = "//span[text()= 'Performance']"

    Dashboard_locator = "//span[text()= 'Dashboard']"

    Directory_locator = "//span[text()= 'Directory']"

    Maintenance_locator = "//span[text()= 'Maintenance']"

    Claim_locator = "//span[text()= 'Claim']"

    Buzz_locator = "//span[text()= 'Buzz']"

    def validate_main_menu_admin(self):
        """this method validate admin page header link text in the main menu"""
        admin_text = self.menu.find_element(By.XPATH, self.admin_page_locator)
        print(f"a) {admin_text.text}")
        time.sleep(2)

    def validate_main_menu_pim(self):
        """this method validate pim page header link text in the main menu"""
        pim_text = self.menu.find_element(By.XPATH, self.PIM_locator)
        print(f"b) {pim_text.text}")
        time.sleep(2)

    def validate_main_menu_leave(self):
        """this method validate leave page header link text in the main menu"""
        leave_text = self.menu.find_element(By.XPATH, self.Leave_locator)
        print(f"c) {leave_text.text}")
        time.sleep(2)

    def validate_main_menu_time(self):
        """this method validate time page header link text in the main menu"""
        time_text = self.menu.find_element(By.XPATH, self.Time_locator)
        print(f"d) {time_text.text}")
        time.sleep(2)

    def validate_main_menu_recruitment(self):
        """this method validate recruitment page header link text in the main menu"""
        recruitment_text = self.menu.find_element(By.XPATH, self.Recruitment_locator)
        print(f"e) {recruitment_text.text}")
        time.sleep(2)

    def validate_main_menu_info(self):
        """this method validate my info page header link text in the main menu"""
        my_info_text = self.menu.find_element(By.XPATH, self.My_info_locator)
        print(f"f) {my_info_text.text}")
        time.sleep(2)

    def validate_main_menu_performance(self):
        """this method validate performance page header link text in the main menu"""
        performance = self.menu.find_element(By.XPATH, self.Performance_locator)
        print(f"g) {performance.text}")
        time.sleep(2)

    def validate_main_menu_dashboard(self):
        """this method validate dashboard page header link text in the main menu"""
        dashboard = self.menu.find_element(By.XPATH, self.Dashboard_locator)
        print(f"h) {dashboard.text}")
        time.sleep(2)

    def validate_main_menu_directory(self):
        """this method validate directory page header link text in the main menu"""
        directory = self.menu.find_element(By.XPATH, self.Directory_locator)
        print(f"i) {directory.text}")
        time.sleep(2)

    def validate_main_menu_maintenance(self):
        """this method validate maintenance page header link text in the main menu"""
        maintenance = self.menu.find_element(By.XPATH, self.Maintenance_locator)
        print(f"j) {maintenance.text}")
        time.sleep(2)

    def validate_main_menu_claim(self):
        """this method validate claim page header link text in the main menu"""
        claim_text = self.menu.find_element(By.XPATH, self.Claim_locator)
        print(f"k) {claim_text.text}")
        time.sleep(2)

    def validate_main_menu_buzz(self):
        """this method validate buzz page header link text in the main menu"""
        buzz_text = self.menu.find_element(By.XPATH, self.Buzz_locator)
        print(f"m) {buzz_text.text}")
        time.sleep(2)
