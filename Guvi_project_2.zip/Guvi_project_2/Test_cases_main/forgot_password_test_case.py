import unittest
from selenium import webdriver

from Login_page.forgot_password_in_login_page import LoginPage
from Screenshot.screenshot_taken import take_screenshot


class LoginTest_class(unittest.TestCase):
    driver = None

    """class method named setUpClass that takes one argument(cls) as it is mention the attribute as @class_method, 
    which is a reference to the class itself. This method is intended to set up any common resources or 
    configurations that will be used by the test cases within the class.setupclass run once before any test methods 
    in the class are executed"""

    @classmethod
    def setUpClass(cls) -> None:
        cls.driver = webdriver.Chrome()  # opens Chrome browser before all testcases
        cls.driver.implicitly_wait(20)
        cls.driver.maximize_window()

    """initiate setup method that arg as (self) since its not a class_method. setup method runs before every testcase"""
    def setUp(self) -> None:
        """ opens the orange hrm url before every testcase"""
        self.driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")

    def test_1_reset_password_successful(self):
        HRM_login = LoginPage(self.driver)  # creating an object for the class LoginPage
        HRM_login.click_forgot_password_link()  # Accessing the method inside the class LoginPage to perform
        HRM_login.forgot_password_page()
        HRM_login.input_username_textbox("Admin")  # passing the argument for the username
        HRM_login.click_reset_password_button()
        HRM_login.forgot_password_reset_successful_page()
        take_screenshot(self.driver)        # this method takes screenshots in end of the testcase

    def test_2_cancel_reset_password(self):
        Hrm_login = LoginPage(self.driver)      # creating an object for the class LoginPage
        Hrm_login.click_forgot_password_link()  # Accessing the method inside the class LoginPage to perform
        Hrm_login.forgot_password_page()
        Hrm_login.click_cancel_button()
        Hrm_login.back_to_login_page()
        take_screenshot(self.driver)        # this method takes screenshots in end of the testcase

    def test_3_click_reset_password_without_entering_username(self):
        login_reset = LoginPage(self.driver)        # creating an object for the class LoginPage
        login_reset.click_forgot_password_link()    # Accessing the method inside the class LoginPage to perform
        login_reset.forgot_password_page()
        login_reset.click_reset_password_button()
        login_reset.required_username_alert()
        take_screenshot(self.driver)        # this method takes screenshots in end of the testcase
