import unittest
from selenium import webdriver

from Admin_page.Admin_main_menu_page import AdminMenu
from Admin_page.Admin_page_options import AdminPage
from Login_page.forgot_password_in_login_page import LoginPage


class Admin(unittest.TestCase):
    driver = None

    """This defines a class method named setUpClass that takes one argument(cls) as it is mention the attribute as 
    @class_method, which is a reference to the class itself. This method is intended to set up any common resources or 
    configurations that will be used by the test cases within the class.setupclass run once before any test 
    methods in the class are executed"""

    @classmethod
    def setUpClass(cls) -> None:
        cls.driver = webdriver.Chrome()
        cls.driver.implicitly_wait(20)
        cls.driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")
        cls.driver.maximize_window()
        Hrm_login = LoginPage(cls.driver)
        Hrm_login.input_username("Admin")
        Hrm_login.input_password("admin123")
        Hrm_login.click_login_btn()

    def test_1_admin_page_header_validation(self):
        """creating an object for AdminPage class and passes the WebDriver self. Driver as an argument."""
        Hrm_admin = AdminPage(self.driver)
        print(self.driver.title)
        Hrm_admin.clicking_on_admin_page()   # accessing the methods inside the class AdminPage
        Hrm_admin.validate_user_management_option_displays()
        Hrm_admin.validate_job_option_displays()
        Hrm_admin.validate_qualification_option_displays()
        Hrm_admin.validate_organization_option_displays()
        Hrm_admin.validate_nationality_option_displays()
        Hrm_admin.validate_corporate_branding_option_displays()
        Hrm_admin.validate_configure_option_displays()

    def test_2_admin_page_main_menu_validation(self):
        """creating an object for AdminMenu class and passes the WebDriver self. Driver as an argument."""
        Hrm_menu = AdminMenu(self.driver)
        Hrm_menu.validate_main_menu_admin()  # accessing the methods inside the class AdminMenu
        Hrm_menu.validate_main_menu_pim()
        Hrm_menu.validate_main_menu_leave()
        Hrm_menu.validate_main_menu_time()
        Hrm_menu.validate_main_menu_recruitment()
        Hrm_menu.validate_main_menu_info()
        Hrm_menu.validate_main_menu_performance()
        Hrm_menu.validate_main_menu_dashboard()
        Hrm_menu.validate_main_menu_directory()
        Hrm_menu.validate_main_menu_maintenance()
        Hrm_menu.validate_main_menu_claim()
        Hrm_menu.validate_main_menu_buzz()
